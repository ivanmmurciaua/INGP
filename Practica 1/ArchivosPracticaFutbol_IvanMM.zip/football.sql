/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

DROP DATABASE IF EXISTS `football`;
CREATE DATABASE IF NOT EXISTS `football` /*!40100 DEFAULT CHARACTER SET utf8 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `football`;

DROP TABLE IF EXISTS `date`;
CREATE TABLE IF NOT EXISTS `date` (
  `iddate` int NOT NULL AUTO_INCREMENT,
  `dia` int DEFAULT NULL,
  `mes` int DEFAULT NULL,
  `anyo` int DEFAULT NULL,
  `clima` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`iddate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `date` DISABLE KEYS */;
INSERT INTO `date` (`iddate`, `dia`, `mes`, `anyo`, `clima`) VALUES
	(1, 5, 2, 2018, 'cold'),
	(2, 7, 8, 2018, 'hot'),
	(3, 14, 3, 2018, 'cold'),
	(4, 22, 10, 2017, 'rainy'),
	(5, 8, 12, 2017, 'cold'),
	(6, 1, 11, 2017, 'cold'),
	(7, 20, 2, 2018, 'cold'),
	(8, 4, 6, 2018, 'hot'),
	(9, 9, 4, 2018, 'rainy'),
	(10, 11, 11, 2017, 'cold');
/*!40000 ALTER TABLE `date` ENABLE KEYS */;

DROP TABLE IF EXISTS `matches`;
CREATE TABLE IF NOT EXISTS `matches` (
  `id` bigint DEFAULT NULL,
  `name` varchar(21) DEFAULT NULL,
  `league` varchar(16) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `matches` DISABLE KEYS */;
INSERT INTO `matches` (`id`, `name`, `league`) VALUES
	(1, 'Madrid vs Barcelona', 'LaLiga Santander'),
	(2, 'Barcelona vs Valencia', 'LaLiga Santander'),
	(3, 'Madrid vs Sevilla', 'LaLiga Santander'),
	(4, 'Valencia vs Sevilla', 'LaLiga Santander');
/*!40000 ALTER TABLE `matches` ENABLE KEYS */;

DROP TABLE IF EXISTS `player`;
CREATE TABLE IF NOT EXISTS `player` (
  `idplayer` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) DEFAULT NULL,
  `posicion` varchar(255) DEFAULT NULL,
  `edad` int DEFAULT NULL,
  `estatura` int DEFAULT NULL,
  PRIMARY KEY (`idplayer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `player` DISABLE KEYS */;
INSERT INTO `player` (`idplayer`, `nombre`, `posicion`, `edad`, `estatura`) VALUES
	(1, 'Ter Stegen', 'goalkeeper', 26, 187),
	(2, 'Jasper Cillessen', 'goalkeeper', 29, 185),
	(3, 'Nelson Cabral Semedo', 'defense', 25, 177),
	(4, 'Gerard Pique', 'defense', 31, 194),
	(5, 'Ivan Rakitic', 'midfield', 30, 184),
	(6, 'Sergio Busquets', 'midfield', 30, 189),
	(7, 'Denis Suarez', 'midfield', 24, 176),
	(8, 'Philippe Coutinho Correia', 'midfield', 26, 172),
	(9, 'Luis Suarez', 'forward', 31, 182),
	(10, 'Lionel Messi', 'forward', 31, 170),
	(11, 'Ousmane Dembele', 'forward', 21, 178),
	(12, 'Rafael Alcantara do Nascimento', 'midfield', 25, 176),
	(13, 'Jordi Alba', 'midfield', 29, 170),
	(14, 'Thomas Vermaelen', 'defense', 33, 183),
	(15, 'Keylor Navas', 'goalkeeper', 31, 185),
	(16, 'Francisco Casilla Cortes', 'goalkeeper', 32, 190),
	(17, 'Daniel Carvajal Ramos', 'defense', 26, 173),
	(18, 'Sergio Ramos Garcia', 'defense', 32, 184),
	(19, 'Jose Ignacio Fernandez Iglesias', 'defense', 28, 180),
	(20, 'Marcelo Vieira da Silva', 'defense', 30, 174),
	(21, 'Toni Kroos', 'midfield', 28, 183),
	(22, 'Luka Modric', 'midfield', 33, 172),
	(23, 'Carlos Henrique Casimiro', 'midfield', 26, 185),
	(24, 'Federico Santiago Valverde Dipetta', 'midfield', 20, 182),
	(25, 'Marco Asensio Willemsen', 'midfield', 22, 182),
	(26, 'Marcos Llorente Moreno', 'midfield', 23, 184),
	(27, 'Francisco Roman Alarcon Suarez', 'midfield', 26, 176),
	(28, 'Karim Benzema', 'forward', 30, 185),
	(29, 'Gareth Bale', 'forward', 29, 185),
	(30, 'Lucas Vazquez Iglesias', 'forward', 27, 173),
	(31, 'Jaume Domenech', 'goalkeeper', 28, 187),
	(32, 'Norberto Murara Neto', 'goalkeeper', 29, 191),
	(33, 'Ruben Miguel Nunes Vezo', 'defense', 24, 184),
	(34, 'Jeison Murillo', 'defense', 26, 182),
	(35, 'Gabriel Armando de Abreu', 'defense', 28, 187),
	(36, 'Mouctar Diakhaby', 'defense', 21, 192),
	(37, 'Geoffrey Kondogbia', 'midfield', 25, 188),
	(38, 'Gonzalo Guedes', 'midfield', 21, 179),
	(39, 'Carlos Soler', 'midfield', 21, 180),
	(40, 'Daniel Parejo', 'midfield', 29, 182),
	(41, 'Kevin Gameiro', 'forward', 31, 172),
	(42, 'Rodrigo Moreno', 'forward', 27, 180),
	(43, 'Santiago Mina Lorenzo', 'forward', 22, 181),
	(44, 'Michy Batshuayi', 'forward', 25, 185),
	(45, 'Tomas Vaclik', 'goalkeeper', 29, 188),
	(46, 'Juan Soriano', 'goalkeeper', 21, 195),
	(47, 'Gabriel Mercado', 'defense', 31, 180),
	(48, 'Sergio Escudero', 'defense', 29, 176),
	(49, 'Simon Kjaer', 'defense', 29, 191),
	(50, 'Guilherme Arana', 'defense', 21, 176),
	(51, 'Sergi Gomez', 'defense', 26, 185),
	(52, 'Pablo Sarabia', 'midfield', 26, 178),
	(53, 'Franco Vazquez', 'midfield', 29, 187),
	(54, 'Jesus Navas', 'midfield', 32, 172),
	(55, 'Ibrahim Amadou', 'midfield', 25, 183),
	(56, 'Manuel Agudo Duran', 'forward', 32, 175),
	(57, 'Wissam Ben Yedder', 'forward', 28, 170),
	(58, 'Andre Silva', 'forward', 23, 184),
	(59, 'Quincy Promes', 'forward', 26, 174);
/*!40000 ALTER TABLE `player` ENABLE KEYS */;

DROP TABLE IF EXISTS `referee`;
CREATE TABLE IF NOT EXISTS `referee` (
  `idreferee` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) DEFAULT NULL,
  `edad` int DEFAULT NULL,
  `pais` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`idreferee`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `referee` DISABLE KEYS */;
INSERT INTO `referee` (`idreferee`, `nombre`, `edad`, `pais`) VALUES
	(1, 'Mario Melero Lopez', 39, 'Spain'),
	(2, 'Jose Luis Munuera Montero', 35, 'Spain'),
	(3, 'Inmaculada Prieto Martinez', 25, 'Spain'),
	(4, 'Maria Jose Villegas Navas', 27, 'Spain'),
	(5, 'Santiago Jaime Latre', 39, 'Spain'),
	(6, 'Pablo Gonzalez Fuertes', 38, 'Spain'),
	(7, 'Paola Cebollada Lopez', 23, 'Spain'),
	(8, 'Alejandro Jose Hernandez Hernandez', 36, 'Spain');
/*!40000 ALTER TABLE `referee` ENABLE KEYS */;

DROP TABLE IF EXISTS `stadium`;
CREATE TABLE IF NOT EXISTS `stadium` (
  `idstadium` int NOT NULL AUTO_INCREMENT,
  `capmax` int DEFAULT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  `calidadterrenojuego` varchar(255) DEFAULT NULL,
  `anyoinaguracion` int DEFAULT NULL,
  `ciudad` varchar(255) DEFAULT NULL,
  `pais` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`idstadium`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `stadium` DISABLE KEYS */;
INSERT INTO `stadium` (`idstadium`, `capmax`, `nombre`, `calidadterrenojuego`, `anyoinaguracion`, `ciudad`, `pais`) VALUES
	(1, 81044, 'Estadio Santiago Bernabeu', 'Good', 1947, 'Madrid', 'Spain'),
	(2, 99354, 'Camp Nou', 'Good', 1954, 'Barcelona', 'Spain'),
	(3, 55000, 'Mestalla', 'Good', 1923, 'Valencia', 'Spain'),
	(4, 43883, 'Ramon Sanchez-Pizjuan', 'Good', 1958, 'Sevilla', 'Spain'),
	(5, 67829, 'Estadio Metropolitano', 'Good', 1994, 'Madrid', 'Spain');
/*!40000 ALTER TABLE `stadium` ENABLE KEYS */;

DROP TABLE IF EXISTS `team`;
CREATE TABLE IF NOT EXISTS `team` (
  `idteam` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) DEFAULT NULL,
  `valoreneuros` float DEFAULT NULL,
  PRIMARY KEY (`idteam`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `team` DISABLE KEYS */;
INSERT INTO `team` (`idteam`, `nombre`, `valoreneuros`) VALUES
	(1, 'Alaves', 61.8),
	(2, 'Athletic', 116),
	(3, 'Atletico Madrid', 347.2),
	(4, 'Barcelona', 897),
	(5, 'Betis', 87.67),
	(6, 'Celta', 68),
	(7, 'Eibar', 45.3),
	(8, 'Espanyol', 74.6),
	(9, 'Getafe', 47.5),
	(10, 'Girona', 44.5),
	(11, 'Huesca', 55),
	(12, 'Leganes', 45.57),
	(13, 'Levante', 57.1),
	(14, 'Rayo Vallecano', 33),
	(15, 'Real Madrid', 690.3),
	(16, 'Real Sociedad', 100.6),
	(17, 'Sevilla', 212),
	(18, 'Valencia', 91.9),
	(19, 'Valladolid', 50),
	(20, 'Villarreal', 117);
/*!40000 ALTER TABLE `team` ENABLE KEYS */;

DROP TABLE IF EXISTS `plays`;
CREATE TABLE IF NOT EXISTS `plays` (
  `idplays` int NOT NULL AUTO_INCREMENT,
  `golesmarcados` int DEFAULT NULL,
  `golesevitados` int DEFAULT NULL,
  `tarjetasmarillas` int DEFAULT NULL,
  `tarjetasrojas` int DEFAULT NULL,
  `tiempodejuego` int DEFAULT NULL,
  `stadium_idstadium` int NOT NULL,
  `referee_idreferee` int NOT NULL,
  `team_idteam` int NOT NULL,
  `matches_idmatches` int NOT NULL,
  `date_iddate` int NOT NULL,
  `player_idplayer` int NOT NULL,
  PRIMARY KEY (`idplays`),
  KEY `fk_plays_stadium_idx` (`stadium_idstadium`),
  KEY `fk_plays_referee1_idx` (`referee_idreferee`),
  KEY `fk_plays_team1_idx` (`team_idteam`),
  KEY `fk_plays_matches1_idx` (`matches_idmatches`),
  KEY `fk_plays_date1_idx` (`date_iddate`),
  KEY `fk_plays_player1_idx` (`player_idplayer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `plays` DISABLE KEYS */;
INSERT INTO `plays` (`idplays`, `golesmarcados`, `golesevitados`, `tarjetasmarillas`, `tarjetasrojas`, `tiempodejuego`, `stadium_idstadium`, `referee_idreferee`, `team_idteam`, `matches_idmatches`, `date_iddate`, `player_idplayer`) VALUES
	(1, 0, 15, 0, 0, 90, 1, 5, 4, 1, 4, 1),
	(2, 0, 0, 0, 0, 0, 1, 5, 4, 1, 4, 2),
	(3, 0, 0, 1, 0, 90, 1, 5, 4, 1, 4, 3),
	(4, 0, 0, 0, 0, 20, 1, 5, 4, 1, 4, 4),
	(5, 0, 0, 0, 0, 90, 1, 5, 4, 1, 4, 5),
	(6, 0, 0, 0, 0, 90, 1, 5, 4, 1, 4, 6),
	(7, 0, 0, 0, 0, 90, 1, 5, 4, 1, 4, 7),
	(8, 0, 0, 1, 0, 90, 1, 5, 4, 1, 4, 8),
	(9, 0, 0, 0, 0, 45, 1, 5, 4, 1, 4, 9),
	(10, 2, 0, 0, 0, 90, 1, 5, 4, 1, 4, 10),
	(11, 0, 0, 0, 0, 90, 1, 5, 4, 1, 4, 11),
	(12, 0, 0, 0, 0, 90, 1, 5, 4, 1, 4, 12),
	(13, 1, 0, 0, 0, 45, 1, 5, 4, 1, 4, 13),
	(14, 0, 0, 0, 0, 70, 1, 5, 4, 1, 4, 14),
	(15, 0, 17, 0, 0, 90, 1, 5, 15, 1, 4, 15),
	(16, 0, 0, 0, 0, 0, 1, 5, 15, 1, 4, 16),
	(17, 0, 0, 0, 0, 90, 1, 5, 15, 1, 4, 17),
	(18, 0, 1, 1, 0, 90, 1, 5, 15, 1, 4, 18),
	(19, 0, 0, 0, 0, 90, 1, 5, 15, 1, 4, 19),
	(20, 0, 0, 0, 0, 0, 1, 5, 15, 1, 4, 20),
	(21, 0, 0, 0, 0, 0, 1, 5, 15, 1, 4, 21),
	(22, 1, 0, 0, 0, 90, 1, 5, 15, 1, 4, 22),
	(23, 0, 0, 1, 0, 45, 1, 5, 15, 1, 4, 23),
	(24, 0, 0, 0, 0, 90, 1, 5, 15, 1, 4, 24),
	(25, 0, 0, 0, 0, 0, 1, 5, 15, 1, 4, 25),
	(26, 0, 0, 0, 1, 60, 1, 5, 15, 1, 4, 26),
	(27, 0, 0, 0, 0, 45, 1, 5, 15, 1, 4, 27),
	(28, 0, 0, 0, 0, 90, 1, 5, 15, 1, 4, 28),
	(29, 1, 0, 0, 0, 90, 1, 5, 15, 1, 4, 29),
	(30, 0, 0, 0, 0, 90, 1, 5, 15, 1, 4, 30),
	(31, 0, 14, 0, 0, 90, 2, 3, 4, 2, 2, 1),
	(32, 0, 0, 0, 0, 0, 2, 3, 4, 2, 2, 2),
	(33, 0, 0, 1, 0, 0, 2, 3, 4, 2, 2, 3),
	(34, 0, 0, 0, 0, 90, 2, 3, 4, 2, 2, 4),
	(35, 0, 0, 0, 1, 80, 2, 3, 4, 2, 2, 5),
	(36, 0, 0, 0, 0, 90, 2, 3, 4, 2, 2, 6),
	(37, 0, 0, 0, 0, 90, 2, 3, 4, 2, 2, 7),
	(38, 1, 0, 0, 0, 90, 2, 3, 4, 2, 2, 8),
	(39, 1, 0, 0, 0, 90, 2, 3, 4, 2, 2, 9),
	(40, 0, 0, 0, 0, 90, 2, 3, 4, 2, 2, 10),
	(41, 0, 0, 1, 0, 90, 2, 3, 4, 2, 2, 11),
	(42, 0, 0, 0, 0, 90, 2, 3, 4, 2, 2, 12),
	(43, 0, 0, 0, 0, 45, 2, 3, 4, 2, 2, 13),
	(44, 0, 0, 0, 0, 45, 2, 3, 4, 2, 2, 14),
	(45, 0, 9, 0, 0, 45, 2, 3, 18, 2, 2, 31),
	(46, 0, 13, 0, 0, 45, 2, 3, 18, 2, 2, 32),
	(47, 0, 0, 0, 0, 90, 2, 3, 18, 2, 2, 33),
	(48, 0, 0, 0, 0, 0, 2, 3, 18, 2, 2, 34),
	(49, 0, 0, 0, 0, 90, 2, 3, 18, 2, 2, 35),
	(50, 0, 0, 0, 0, 45, 2, 3, 18, 2, 2, 36),
	(51, 0, 0, 0, 0, 90, 2, 3, 18, 2, 2, 37),
	(52, 0, 0, 0, 0, 90, 2, 3, 18, 2, 2, 38),
	(53, 0, 0, 1, 0, 90, 2, 3, 18, 2, 2, 39),
	(54, 0, 0, 0, 0, 90, 2, 3, 18, 2, 2, 40),
	(55, 1, 0, 0, 0, 90, 2, 3, 18, 2, 2, 41),
	(56, 0, 0, 0, 0, 90, 2, 3, 18, 2, 2, 42),
	(57, 0, 0, 0, 0, 45, 2, 3, 18, 2, 2, 43),
	(58, 0, 0, 0, 0, 90, 2, 3, 18, 2, 2, 44),
	(59, 0, 20, 0, 0, 90, 1, 1, 15, 3, 6, 15),
	(60, 0, 0, 0, 0, 0, 1, 1, 15, 3, 6, 16),
	(61, 0, 0, 0, 0, 90, 1, 1, 15, 3, 6, 17),
	(62, 0, 0, 1, 0, 90, 1, 1, 15, 3, 6, 18),
	(63, 0, 0, 0, 0, 0, 1, 1, 15, 3, 6, 19),
	(64, 0, 0, 0, 0, 60, 1, 1, 15, 3, 6, 20),
	(65, 0, 0, 0, 0, 0, 1, 1, 15, 3, 6, 21),
	(66, 0, 0, 0, 0, 90, 1, 1, 15, 3, 6, 22),
	(67, 0, 0, 0, 0, 30, 1, 1, 15, 3, 6, 23),
	(68, 0, 0, 0, 0, 90, 1, 1, 15, 3, 6, 24),
	(69, 0, 0, 1, 0, 45, 1, 1, 15, 3, 6, 25),
	(70, 0, 0, 0, 0, 45, 1, 1, 15, 3, 6, 26),
	(71, 0, 0, 0, 0, 90, 1, 1, 15, 3, 6, 27),
	(72, 1, 0, 0, 0, 90, 1, 1, 15, 3, 6, 28),
	(73, 1, 0, 0, 0, 90, 1, 1, 15, 3, 6, 29),
	(74, 0, 0, 0, 0, 90, 1, 1, 15, 3, 6, 30),
	(75, 0, 19, 0, 0, 90, 1, 1, 17, 3, 6, 45),
	(76, 0, 0, 0, 0, 0, 1, 1, 17, 3, 6, 46),
	(77, 0, 0, 0, 0, 90, 1, 1, 17, 3, 6, 47),
	(78, 0, 0, 1, 0, 90, 1, 1, 17, 3, 6, 48),
	(79, 0, 1, 0, 0, 75, 1, 1, 17, 3, 6, 49),
	(80, 0, 0, 0, 0, 90, 1, 1, 17, 3, 6, 50),
	(81, 0, 0, 0, 1, 83, 1, 1, 17, 3, 6, 51),
	(82, 0, 0, 0, 0, 90, 1, 1, 17, 3, 6, 52),
	(83, 0, 0, 0, 0, 45, 1, 1, 17, 3, 6, 53),
	(84, 0, 0, 1, 0, 90, 1, 1, 17, 3, 6, 54),
	(85, 0, 0, 0, 0, 15, 1, 1, 17, 3, 6, 55),
	(86, 0, 0, 0, 0, 45, 1, 1, 17, 3, 6, 56),
	(87, 0, 0, 0, 0, 0, 1, 1, 17, 3, 6, 57),
	(88, 0, 0, 0, 0, 90, 1, 1, 17, 3, 6, 58),
	(89, 0, 0, 0, 0, 90, 1, 1, 17, 3, 6, 59),
	(90, 0, 16, 1, 0, 60, 3, 7, 18, 4, 8, 31),
	(91, 0, 12, 0, 0, 30, 3, 7, 18, 4, 8, 32),
	(92, 0, 0, 0, 0, 90, 3, 7, 18, 4, 8, 33),
	(93, 0, 0, 0, 0, 90, 3, 7, 18, 4, 8, 34),
	(94, 0, 0, 0, 0, 70, 3, 7, 18, 4, 8, 35),
	(95, 0, 0, 1, 0, 90, 3, 7, 18, 4, 8, 36),
	(96, 0, 0, 0, 0, 0, 3, 7, 18, 4, 8, 37),
	(97, 0, 0, 0, 0, 90, 3, 7, 18, 4, 8, 38),
	(98, 0, 0, 0, 0, 90, 3, 7, 18, 4, 8, 39),
	(99, 0, 0, 0, 0, 20, 3, 7, 18, 4, 8, 40),
	(100, 0, 0, 0, 0, 90, 3, 7, 18, 4, 8, 41),
	(101, 1, 0, 1, 0, 90, 3, 7, 18, 4, 8, 42),
	(102, 0, 0, 0, 0, 90, 3, 7, 18, 4, 8, 43),
	(103, 0, 0, 0, 0, 90, 3, 7, 18, 4, 8, 44),
	(104, 0, 17, 0, 0, 90, 3, 7, 17, 4, 8, 45),
	(105, 0, 0, 0, 0, 0, 3, 7, 17, 4, 8, 46),
	(106, 0, 0, 0, 0, 90, 3, 7, 17, 4, 8, 47),
	(107, 0, 0, 0, 0, 45, 3, 7, 17, 4, 8, 48),
	(108, 0, 0, 0, 0, 90, 3, 7, 17, 4, 8, 49),
	(109, 0, 0, 1, 0, 90, 3, 7, 17, 4, 8, 50),
	(110, 0, 0, 0, 0, 0, 3, 7, 17, 4, 8, 51),
	(111, 0, 0, 0, 0, 45, 3, 7, 17, 4, 8, 52),
	(112, 0, 0, 0, 0, 90, 3, 7, 17, 4, 8, 53),
	(113, 0, 0, 0, 0, 50, 3, 7, 17, 4, 8, 54),
	(114, 0, 0, 0, 0, 90, 3, 7, 17, 4, 8, 55),
	(115, 0, 0, 0, 0, 90, 3, 7, 17, 4, 8, 56),
	(116, 0, 0, 1, 0, 90, 3, 7, 17, 4, 8, 57),
	(117, 1, 0, 0, 0, 40, 3, 7, 17, 4, 8, 58),
	(118, 0, 0, 0, 0, 90, 3, 7, 17, 4, 8, 59);
/*!40000 ALTER TABLE `plays` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;